
/**
 * This is 28th of March 2022
 *Time 22.02
 * @author (Sahil raj)
 * First step towards learning java (program 1)
 */
public class Unicode_Examples
{
    public static void main()
    {
    System.out.println("\u0928\u092E\u0938\u094D\u0924\u0947! \u092E\u0947\u0930\u093E \u0928\u093E\u092E \u0938\u093E\u0939\u093F\u0932 \u0939\u0948");
    }
}

